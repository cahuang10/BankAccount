import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

//Click to add an import
public class Tests {

  @Test
  public void test1() {
    // Failure message:
    // after creating an account with $1,000 withdraw $300, deposit $500, withdraw
    // $100, the balance should be 1098.50
    CheckingAccount joesAccount = new CheckingAccount(1000);
    joesAccount.withdraw(300);
    joesAccount.deposit(500);
    joesAccount.withdraw(100);
    assertTrue("FAILURE: after creating an account with $1,000 withdraw $300, deposit $500,\n withdraw $100, the balance should be 1098.50 \n", 1098.5 == joesAccount.getBalance());
  }

  @Test
  public void test2() {
    // Failure message:
    // after creating an account with $500 transfer $100 to joesAcount from
    // moesAccount, the balance of joesaccount should be 1098.50
    CheckingAccount joesAccount = new CheckingAccount(1000);
    joesAccount.withdraw(300);
    joesAccount.deposit(500);
    joesAccount.withdraw(100);
    CheckingAccount moesAccount = new CheckingAccount(500);
    moesAccount.transfer(100, joesAccount);
    assertTrue("FAILURE: after creating an account with $500 transfer $100 to joesAcount from moesAccount,\n the balance of joesaccount should be 1098.50\n", 1198.0 == joesAccount.getBalance());
  }

  @Test
  public void test3() {
    // Failure message:
    // after creating an account with $2,000 with a rate of 4.2 withdraw $1,000 the
    // balance of the account should be $1,000
    SavingsAccount janesAccount = new SavingsAccount(2000, 4.2);
    janesAccount.withdraw(1000);
    assertTrue("FAILURE:after creating an account with $2,000 with a rate of 4.2 withdraw $1,000\n the balance of the account should be $1,000\n" , 1000 == janesAccount.getBalance());
  }

  @Test
  public void test4() {
    // Failure message:
    // after creating an account with $1,000 with a rate of 4.2 withdraw $1,000 the
    // balance of the account should be $1,000 because the withdraw is not
    // authorised
    SavingsAccount janesAccount = new SavingsAccount(1000, 4.2);
    janesAccount.withdraw(1000); // withdrawel not allowed
    assertTrue("FAILURE: after creating an account with $1,000 with a rate of 4.2 withdraw $1,000 \nthe balance of the account should be $1,000 \nbecause the withdraw is not authorised\n", 1000 == janesAccount.getBalance());
  }

  @Test
  public void test5() {
    // Failure message:
    // after creating an account with $1,000 with a rate of 4.2 withdraw $995 the
    // balance of the account should be $1,000 because the withdraw is not
    // authorised
    SavingsAccount janesAccount = new SavingsAccount(1000, 4.2);
    janesAccount.withdraw(995); // withdraw not allowed
    assertTrue("FAILURE: after creating an account with $1,000 with a rate of 4.2 \n withdraw $995 the balance of the account should be $1,000 \nbecause the withdraw is not authorised\n", 1000 == janesAccount.getBalance());
  }

  @Test
  public void test6() {
    // Failure message:
    // after creating an account with $1,000 with a rate of 4.2 add the interest.The
    // balance of the account should be $1,042

    SavingsAccount janesAccount = new SavingsAccount(1000, 4.2);
    janesAccount.addInterest();
    assertTrue("FAILURE: after creating an account with $1,000 with a rate of 4.2 add the interest.\nThe balance of the account should be $1,042\n", 1042 == janesAccount.getBalance());
  }
}