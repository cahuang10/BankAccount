/**     
*       <<< THIS CODE IS NOT COMPLETE >>>
*   An account that earns interest at a fixed rate.
*/
 class SavingsAccount extends BankAccount
{
   private double interestRate;
   public static final double MINIMUM_BALANCE = 10;
   
   /**   <<< COMPLETE THIS METHOD >>>
   *   Constructs a bank account with a given interest rate.
   */
   public SavingsAccount(double rate)  {
        // <<<  CODE NOT COMPLETE >>>
        this.interestRate=rate;
   }

   /**   <<< COMPLETE THIS METHOD >>>
    *   Constructs a bank account with a given balance
    *   and a given interest rate.
    */
   public SavingsAccount(double initialBalance, double rate) {
       // <<<  CODE NOT COMPLETE >>>
       super(initialBalance);
       this.interestRate=rate;
   }
   
   
   /**  <<< COMPLETE THIS METHOD >>>
   *   Adds the earned interest to the account balance.
   */
   public void addInterest()   {
       // <<< CODE NOT COMPLETE >>>
    this.deposit(getBalance()*interestRate/100);
   }
   
   /** <<< COMPLETE THIS METHOD>>>
    *  overrides withdraw in the superclass
    *  only allows withdrawel to occur if 
    *  resulting balance > MINIMUM_BALANCE
    */
    public void withdraw(double amount)  {
      super.withdraw(amount);
      if(!(this.getBalance()>MINIMUM_BALANCE)){
        super.deposit(amount);
      }
   }
}


