The classes Main, BankAccount are complete.

  1. Draw the hierarchy first.

  2. SavingsAccount:

  Code the 2 constructors, addInterest, withdraw

  3. CheckingAccount:

  Code the constructor, deposit, withdraw, transfer

  Test: 
  **java -classpath .:/run_dir/junit-4.12.jar:target/dependency/* TestsRunner**


